from hubspot import HubSpot
from django.conf import settings

def get_hubspot_client():
    return HubSpot(access_token=settings.HUBSPOT_ACCESS_TOKEN)
