from django.urls import path
from .views import CreateViewHubSpotClient, ReadUpdateDeleteHubSpotClient

urlpatterns = [
    
    path("hubspots/", CreateViewHubSpotClient.as_view()),              # List & Create
    path("hubspot/<str:contact_id>/", ReadUpdateDeleteHubSpotClient.as_view()),  # Get, Update, Delete
]
