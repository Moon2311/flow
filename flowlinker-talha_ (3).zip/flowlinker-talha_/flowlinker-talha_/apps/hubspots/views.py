from hubspot import HubSpot
from hubspot.crm.contacts import SimplePublicObjectInput
from hubspot.crm.contacts.exceptions import ApiException
from django.conf import settings
from requests import Response # assuming you store your token here
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from hubspot.crm.contacts import ApiException
from .utils import get_hubspot_client
from rest_framework.permissions import IsAuthenticated


class CreateViewHubSpotClient(APIView):    
    # -------------------------
    # CRUD Operations
    # -------------------------
    permission_classes = [IsAuthenticated]
    def get(self, request):
        """Retrieve all contacts from HubSpot"""
        client = get_hubspot_client()
        try:
            properties = ["firstname", "lastname", "email", "phone"]
            all_contacts = client.crm.contacts.get_all(properties=properties)

            contacts = [{
                "id": c.id,
                "firstname": c.properties.get("firstname"),
                "lastname": c.properties.get("lastname"),
                "email": c.properties.get("email"),
                "phone": c.properties.get("phone"),
            } for c in all_contacts]

            return Response(contacts)

        except ApiException as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    
    def post(self, request):
        """Create a new contact"""
        try:
            data = request.data
            contact_input = {
                "email": data.get("email"),
                "firstname": data.get("firstname"),
                "lastname": data.get("lastname"),
                "phone": data.get("phone"),
            }

            client = get_hubspot_client()   # 🔑 ensures token is attached
            contact = client.crm.contacts.basic_api.create({"properties": contact_input})

            return Response({"id": contact.id, "message": "Contact created successfully!","data": contact_input})
        except ApiException as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class ReadUpdateDeleteHubSpotClient(APIView):
    permission_classes = [IsAuthenticated]
    client = get_hubspot_client()  # Initialize HubSpot client once  
    
    def get(self, request, contact_id: str):
        """Retrieve a contact by ID."""
        try:
            contact = self.client.crm.contacts.basic_api.get_by_id(contact_id, properties=["firstname", "lastname", "email", "phone"])
            contact_data = {
                "id": contact.id,
                "firstname": contact.properties.get("firstname"),
                "lastname": contact.properties.get("lastname"),
                "email": contact.properties.get("email"),
                "phone": contact.properties.get("phone"),
            }
            return Response(contact_data, status=status.HTTP_200_OK)
        except ApiException as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, contact_id: str):
        """Update a contact by ID with provided properties."""
        try:
            updates = request.data
            update_input = SimplePublicObjectInput(properties=updates)
            updated_contact = self.client.crm.contacts.basic_api.update(contact_id, update_input)
            return Response(
                {"id": updated_contact.id, "message": "Contact updated successfully!", "data": updates},

                status=status.HTTP_200_OK
            )
        except ApiException as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, contact_id: str):
        """Delete (archive) a contact by ID."""
        try:
            self.client.crm.contacts.basic_api.archive(contact_id)
            return Response(
                {"id": contact_id, "message": "Contact deleted successfully!"},
                status=status.HTTP_204_NO_CONTENT
            )
        except ApiException as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


    



