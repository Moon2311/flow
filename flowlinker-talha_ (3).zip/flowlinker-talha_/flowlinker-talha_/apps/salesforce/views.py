from rest_framework import viewsets, status
from rest_framework.response import Response
from .serializers import LeadSerializer
from .utiles import get_salesforce
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticated


class LeadViewSet(viewsets.ViewSet):
    """
    ViewSet for CRUD operations on Salesforce Leads
    """

    permission_classes = [IsAuthenticated]

    def list(self, request):
        sf = get_salesforce()
        search = request.query_params.get("search")

        # Build dynamic WHERE clause
        where_clause = ""
        if search:
            where_clause = (
                f"WHERE FirstName LIKE '%{search}%' OR LastName LIKE '%{search}%'"
            )

        soql = f"""
            SELECT Id, FirstName, LastName, Company, Title, Website, Description,
                Email, Phone, Street, City, State, StateCode, PostalCode, Country,
                Status, LeadSource, Industry, AnnualRevenue, NumberOfEmployees,
                CreatedDate, LastModifiedDate, OwnerId
            FROM Lead
            {where_clause}
        """

        query = sf.query(soql)
        serializer = LeadSerializer(query["records"], many=True)

        # Apply DRF pagination
        paginator = PageNumberPagination()
        paginated_data = paginator.paginate_queryset(serializer.data, request)
        return paginator.get_paginated_response(paginated_data)

    # Retrieve single Lead
    def retrieve(self, request, pk=None):
        sf = get_salesforce()
        try:
            lead = sf.Lead.get(pk)
            serializer = LeadSerializer(lead)
            return Response(serializer.data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_404_NOT_FOUND)

    # Create new Lead
    def create(self, request):
        serializer = LeadSerializer(data=request.data)
        if serializer.is_valid():
            sf = get_salesforce()
            result = sf.Lead.create(serializer.validated_data)
            return Response(result, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # Full Update (PUT)
    def update(self, request, pk=None):
        serializer = LeadSerializer(data=request.data)
        if serializer.is_valid():
            sf = get_salesforce()
            try:
                sf.Lead.update(pk, serializer.validated_data)
                return Response({"message": "Lead updated"})
            except Exception as e:
                return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # Partial Update (PATCH)
    def partial_update(self, request, pk=None):
        sf = get_salesforce()
        serializer = LeadSerializer(data=request.data, partial=True)
        if serializer.is_valid():
            try:
                sf.Lead.update(pk, serializer.validated_data)
                return Response({"message": "Lead partially updated"})
            except Exception as e:
                return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # Delete Lead
    def destroy(self, request, pk=None):
        sf = get_salesforce()
        try:
            sf.Lead.delete(pk)
            return Response(
                {"detail": f"Lead {pk} deleted successfully."},
                status=status.HTTP_200_OK,
            )
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
