from rest_framework import serializers


class LeadSerializer(serializers.Serializer):
    # Salesforce Id (read-only)
    Id = serializers.CharField(read_only=True)

    # Basic Info
    FirstName = serializers.CharField(required=False, allow_blank=True)
    LastName = serializers.CharField(required=True)
    Company = serializers.CharField(required=True)
    Title = serializers.CharField(required=False, allow_blank=True)
    Website = serializers.URLField(required=False, allow_blank=True)
    Description = serializers.CharField(required=False, allow_blank=True)

    # Contact Info
    Phone = serializers.CharField(required=False, allow_blank=True)
    Email = serializers.EmailField(required=False, allow_blank=True)

    # Address
    Street = serializers.CharField(required=False, allow_blank=True)
    City = serializers.CharField(required=False, allow_blank=True)
    State = serializers.CharField(required=False, allow_blank=True)
    StateCode = serializers.CharField(required=False, allow_blank=True)
    PostalCode = serializers.CharField(required=False, allow_blank=True)
    CountryCode = serializers.CharField(required=False, allow_blank=True)
    Country = serializers.CharField(required=False, allow_blank=True)

    # Lead Info
    Status = serializers.CharField(
        required=False, allow_blank=True
    )  # Open, Contacted, Converted, etc.
    LeadSource = serializers.CharField(
        required=False, allow_blank=True
    )  # Web, Phone Inquiry, etc.
    Industry = serializers.CharField(required=False, allow_blank=True)
    AnnualRevenue = serializers.DecimalField(
        required=False, max_digits=18, decimal_places=2
    )
    NumberOfEmployees = serializers.IntegerField(required=False)

    # Audit fields (read-only)
    CreatedDate = serializers.DateTimeField(read_only=True)
    LastModifiedDate = serializers.DateTimeField(read_only=True)
    OwnerId = serializers.CharField(read_only=True)
