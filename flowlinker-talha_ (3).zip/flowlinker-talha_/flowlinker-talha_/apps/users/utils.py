import re
from django.core.exceptions import ValidationError

def custom_email_validator(value):
    # Ensure email format and disallow "+" in local part
    if "+" in value.split("@")[0] or not re.match(
        r"^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$", value
    ):
        raise ValidationError(
            "Invalid email format. Special characters other than . _ - are not allowed in the local part."
        )