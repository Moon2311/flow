from django.urls import path
from .views import (
    LoginView,
    UserRetrieveUpdateDestroyAPIView,
    UserRegisterView,
    UserListView,
)

urlpatterns = [
    # Custom registration and listing views
    path("register/", UserRegisterView.as_view(), name="user-register"),
    path("list/", UserListView.as_view(), name="user-list"),
    path("login/", LoginView.as_view(), name="login"),
    # DRF-style CRUD views
    path(
        "user/<int:pk>/", UserRetrieveUpdateDestroyAPIView.as_view(), name="user-detail"
    ),
]
