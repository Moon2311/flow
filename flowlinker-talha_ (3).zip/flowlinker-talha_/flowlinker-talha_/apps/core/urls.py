from django.urls import path

from .views import (
    GoogleCalendarInitView,
    GoogleCalendarRedirectView,
    UpcomingMeetingsView,
    ZoomRedirectView,
    zoom_authorize,
)

urlpatterns = [
    path(
        "google-meet/init/", GoogleCalendarInitView.as_view(), name="google-meet-init"
    ),
    path(
        "google-meet/redirect/",
        GoogleCalendarRedirectView.as_view(),
        name="google-meet-redirect",
    ),
    path(
        "meetings/upcoming/", UpcomingMeetingsView.as_view(), name="upcoming-meetings"
    ),
    path("zoom/init/", zoom_authorize, name="zoom-init"),
    path("zoom/redirect/", ZoomRedirectView.as_view(), name="zoom-redirect"),
    # path("google-test/", fetch_google_calendar_events, name="google-test"),
]
