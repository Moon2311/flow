from django.contrib import admin
from .models import Credential, Meeting, Attendee


@admin.register(Credential)
class CredentialAdmin(admin.ModelAdmin):
    list_display = (
        "user",
        "platform",
        "token_expiry",
        "created_at",
        "updated_at",
        "is_archived",
    )
    list_filter = ("platform", "is_archived")
    search_fields = ("user__username", "user__email", "platform")
    readonly_fields = ("created_at", "updated_at")
    list_select_related = ("user",)


class AttendeeInline(admin.TabularInline):
    model = Attendee
    extra = 0  # no empty rows by default
    fields = ("email", "response_status")
    readonly_fields = ()
    show_change_link = True


@admin.register(Meeting)
class MeetingAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "platform",
        "user",
        "start_time",
        "end_time",
        "meeting_url",
        "is_archived",
    )
    list_filter = ("platform", "is_archived", "start_time")
    search_fields = ("title", "meeting_id", "user__username", "user__email")
    readonly_fields = ("created_at", "updated_at")
    list_select_related = ("user",)
    inlines = [AttendeeInline]


@admin.register(Attendee)
class AttendeeAdmin(admin.ModelAdmin):
    list_display = ("meeting", "email", "response_status")
    list_filter = ("response_status",)
    search_fields = ("email", "meeting__title", "meeting__meeting_id")
    list_select_related = ("meeting",)
