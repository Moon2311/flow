from rest_framework import serializers
from .models import Meeting, Attendee


class AttendeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendee
        fields = ["email", "response_status"]


class MeetingSerializer(serializers.ModelSerializer):
    attendees = AttendeeSerializer(many=True, read_only=True)

    class Meta:
        model = Meeting
        fields = [
            "meeting_id",
            "platform",
            "title",
            "description",
            "start_time",
            "end_time",
            "meeting_url",
            "attendees",
        ]
