import uuid
from django.conf import settings
from django.db import models
from apps.users.models import User
from django.db import models
import uuid


class BaseModel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name="%(class)s_created",
    )
    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name="%(class)s_updated",
    )
    is_archived = models.BooleanField(default=False)

    class Meta:
        abstract = True
        ordering = ["-created_at"]

class Credential(BaseModel):
    """Model to store OAuth credentials for different platforms."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='credentials')
    platform = models.CharField(
        max_length=50,
        choices=[
            ('google', 'Google Calendar'),
            ('outlook', 'Outlook'),
            ('teams', 'Microsoft Teams'),
            ('zoom', 'Zoom')
        ]
    )
    access_token = models.TextField()
    refresh_token = models.TextField(null=True, blank=True)
    token_expiry = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'credentials'
        unique_together = ['user', 'platform']

class Meeting(BaseModel):
    """Model to store meeting details from various platforms."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='meetings')
    platform = models.CharField(
        max_length=50,
        choices=[
            ('google', 'Google Calendar'),
            ('outlook', 'Outlook'),
            ('teams', 'Microsoft Teams'),
            ('zoom', 'Zoom')
        ]
    )
    meeting_id = models.CharField(max_length=255)  # Platform-specific meeting ID
    title = models.CharField(max_length=255)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    meeting_url = models.URLField(null=True, blank=True)  # For Zoom/Teams links

    class Meta:
        db_table = 'meetings'
        indexes = [
            models.Index(fields=['user', 'platform']),
            models.Index(fields=['start_time']),
        ]

class Attendee(models.Model):
    """Model to store attendee details for meetings."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    meeting = models.ForeignKey(Meeting, on_delete=models.CASCADE, related_name='attendees')
    email = models.EmailField()  # Primary identifier for attendees
    # name = models.CharField(max_length=255, null=True, blank=True)  # Optional name
    response_status = models.CharField(
        max_length=50,
        choices=[
            ('needsAction', 'Needs Action'),
            ('accepted', 'Accepted'),
            ('declined', 'Declined'),
            ('tentative', 'Tentative'),
            ('none', 'None')  # Fallback for platforms like Zoom
        ],
        default='none'
    )

    class Meta:
        db_table = 'attendees'
        unique_together = ['meeting', 'email']  # Prevent duplicate attendees per meeting
        indexes = [
            models.Index(fields=['meeting', 'email']),
        ]