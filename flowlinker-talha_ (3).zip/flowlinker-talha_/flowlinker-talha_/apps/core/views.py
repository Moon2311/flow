import base64
import os
from pathlib import Path
import datetime
from django.shortcuts import redirect
import requests
from rest_framework.views import APIView
from rest_framework.response import Response
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from django.conf import settings
from django.utils import timezone
from django.urls import reverse
from rest_framework import status
from django.db.models import Q
from rest_framework.generics import ListAPIView


from apps.core.serializers import MeetingSerializer
from apps.users.models import User
from .models import Credential, Meeting, Attendee

ZOOM_CLIENT_ID = settings.ZOOM_CLIENT_ID
ZOOM_REDIRECT_URI = settings.ZOOM_REDIRECT_URI
REDIRECT_URI = settings.GOOGLE_REDIRECT_URI

# Path to credentials.json
CLIENT_SECRETS_FILE = Path(__file__).resolve().parent.parent.parent / "credentials.json"
SCOPES = settings.GOOGLE_SCOPES


class GoogleCalendarInitView(APIView):
    def get(self, request):
        # if not request.user.is_authenticated:
        #     return redirect(reverse('login'))  # Redirect to login page
        flow = Flow.from_client_secrets_file(
            CLIENT_SECRETS_FILE, scopes=SCOPES, redirect_uri=REDIRECT_URI
        )
        authorization_url, state = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            prompt="consent",
        )
        request.session["oauth_state"] = state
        request.session["platform"] = "google"
        return redirect(authorization_url)


class GoogleCalendarRedirectView(APIView):
    def get(self, request):
        # if not request.user.is_authenticated:
        #     return redirect(reverse('login'))  # Redirect to login page

        # query user data
        email = "admin@gmail.com"
        user = User.objects.get(email=email)
        print(user)
        state = request.session.get("oauth_state")
        if not state or state != request.GET.get("state"):
            return Response({"error": "Invalid state parameter."}, status=400)

        flow = Flow.from_client_secrets_file(
            CLIENT_SECRETS_FILE, scopes=SCOPES, state=state, redirect_uri=REDIRECT_URI
        )

        try:
            flow.fetch_token(authorization_response=request.build_absolute_uri())
            creds = flow.credentials

            # Store credentials in the database
            Credential.objects.update_or_create(
                user=user,
                platform="google",
                defaults={
                    "access_token": creds.token,
                    "refresh_token": creds.refresh_token,
                    "token_expiry": creds.expiry,
                    "created_by": user,
                    "updated_by": user,
                    "is_archived": False,
                },
            )

            # Build Google Calendar service
            service = build("calendar", "v3", credentials=creds)
            now = timezone.now().isoformat()

            events_result = (
                service.events()
                .list(
                    calendarId="primary",
                    timeMin=now,
                    maxResults=50,  # maybe fetch more
                    singleEvents=True,
                    orderBy="startTime",
                )
                .execute()
            )

            events = events_result.get("items", [])

            organized_events = [
                e
                for e in events
                if e.get("organizer", {}).get(
                    "self", False
                )  # only events user organizes
            ]

            if not organized_events:
                return Response({"message": "No upcoming events found."}, status=200)

            formatted_events = []
            for event in organized_events:
                start = event["start"].get("dateTime", event["start"].get("date"))
                end = event["end"].get("dateTime", event["end"].get("date"))

                # Store or update meeting in the database
                meeting, _ = Meeting.objects.update_or_create(
                    user=user,
                    platform="google",
                    meeting_id=event["id"],
                    defaults={
                        "title": event.get("summary", "No title"),
                        "start_time": start,
                        "end_time": end,
                        "description": event.get("description", ""),
                        "meeting_url": event.get("hangoutLink", ""),
                        "created_by": user,
                        "updated_by": user,
                        "is_archived": False,
                    },
                )

                # Store or update attendees
                attendees = event.get("attendees", [])
                for attendee in attendees:
                    email = attendee.get("email")
                    if email:
                        Attendee.objects.update_or_create(
                            meeting=meeting,
                            email=email,
                            defaults={
                                "response_status": attendee.get(
                                    "responseStatus", "none"
                                )
                            },
                        )

                # Prepare response data
                formatted_attendees = [
                    {
                        "email": attendee.get("email"),
                        "response_status": attendee.get("responseStatus", "none"),
                    }
                    for attendee in attendees
                    if attendee.get("email")
                ]

                formatted_events.append(
                    {
                        "meeting_id": event["id"],
                        "start": start,
                        "end": end,
                        "summary": event.get("summary", "No title"),
                        "description": event.get("description", ""),
                        "meeting_url": event.get("hangoutLink", ""),
                        "attendees": formatted_attendees,
                    }
                )

            return Response(formatted_events)

        except Exception as e:
            return Response({"error": f"An error occurred: {e}"}, status=500)


class UpcomingMeetingsView(ListAPIView):
    serializer_class = MeetingSerializer

    def get_queryset(self):
        now = timezone.now()
        return (
            Meeting.objects.filter(end_time__gte=now, is_archived=False)
            .order_by("start_time")
            .select_related("user")
            .prefetch_related("attendees")
        )


# --- Zoom Helper Functions and Views ---


def get_zoom_meetings(access_token):
    """
    Fetches upcoming meetings from the Zoom API.
    """
    api_url = "https://api.zoom.us/v2/users/me/meetings"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    try:
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        return response.json().get("meetings", [])
    except requests.exceptions.RequestException as e:
        print(f"Error fetching Zoom meetings: {e}")
        return []


import requests


def get_zoom_meeting_participants(access_token, meeting_uuid, page_size=300):
    """
    Fetches the list of participants for a given Zoom meeting using the Reports API.

    Args:
        access_token (str): The OAuth 2.0 access token with 'meeting:read:report' scope.
        meeting_uuid (str): The universally unique ID (UUID) of the past meeting.
                            Note: If the UUID contains a '/', it must be double-encoded.
        page_size (int): The number of records to return per page. Max is 300.

    Returns:
        list: A list of participant dictionaries, or an empty list if an error occurs.
    """
    base_url = "https://api.zoom.us/v2/report/meetings"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }

    participants = []
    next_page_token = None

    while True:
        try:
            params = {
                "page_size": page_size,
            }
            if next_page_token:
                params["next_page_token"] = next_page_token

            # Zoom's API endpoint to get a participant report
            api_url = f"{base_url}/{meeting_uuid}/participants"
            response = requests.get(api_url, headers=headers, params=params)
            response.raise_for_status()

            data = response.json()
            participants.extend(data.get("participants", []))

            # Check for pagination and continue if more results exist
            next_page_token = data.get("next_page_token")
            if not next_page_token:
                break

        except requests.exceptions.RequestException as e:
            print(f"Error fetching Zoom meeting participants: {e}")
            print(f"Response content: {response.text}")
            return []

    return participants


def zoom_authorize(request):
    """
    Redirects to the Zoom OAuth 2.0 authorization URL.
    """
    auth_url = (
        f"https://zoom.us/oauth/authorize?response_type=code&client_id={settings.ZOOM_CLIENT_ID}"
        f"&redirect_uri={settings.ZOOM_REDIRECT_URI}"
    )
    return redirect(auth_url)


class ZoomRedirectView(APIView):
    def get(self, request):
        """
        Handles the redirect from Zoom's OAuth 2.0 service and fetches user meetings.
        """
        authorization_code = request.GET.get("code")
        if not authorization_code:
            return Response(
                {"error": "Authorization code missing"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Prepare for the token exchange request
        client_auth = f"{settings.ZOOM_CLIENT_ID}:{settings.ZOOM_CLIENT_SECRET}"
        encoded_auth = base64.b64encode(client_auth.encode()).decode()

        token_url = "https://zoom.us/oauth/token"
        headers = {
            "Authorization": f"Basic {encoded_auth}",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        data = {
            "grant_type": "authorization_code",
            "code": authorization_code,
            "redirect_uri": settings.ZOOM_REDIRECT_URI,  # Use settings for production readiness
        }

        try:
            response = requests.post(token_url, headers=headers, data=data)
            response.raise_for_status()
            token_data = response.json()
            access_token = token_data.get("access_token")

            if not access_token:
                return Response(
                    {"error": "Access token not found in response"},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # NOTE: You should save the access token and refresh token in the Credential model here.
            # Example:
            # user = ... # Retrieve the logged-in user
            # Credential.objects.update_or_create(
            #    user=user,
            #    platform='zoom',
            #    defaults={
            #        'access_token': access_token,
            #        'refresh_token': token_data.get('refresh_token'),
            #        'token_expiry': timezone.now() + datetime.timedelta(seconds=token_data.get('expires_in')),
            #        ...
            #    }
            # )

            meetings = get_zoom_meetings(access_token)
            meeting_id = meetings[0]["id"]

            Attendees = get_zoom_meeting_participants(
                access_token, meeting_id, page_size=300
            )

            # NOTE: You should parse and save the meetings to your Meeting and Attendee models here.
            # Example parsing loop:
            # for meeting_data in meetings:
            #    Meeting.objects.update_or_create(...)
            #    Attendee.objects.update_or_create(...)

            return Response(
                {"meetings": meetings, "Attendees": Attendees},
                status=status.HTTP_200_OK,
            )

        except requests.exceptions.RequestException as e:
            # This handles both token exchange and meeting fetch errors
            error_message = f"Failed to get access token or fetch meetings: {e}"
            return Response(
                {"error": error_message}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )