import requests
import json
import os
import time
from dotenv import load_dotenv

load_dotenv()

# Get the API key from an environment variable for security
RECALL_API_KEY = os.getenv("RECALL_API_KEY")

if not RECALL_API_KEY:
    raise ValueError("RECALL_AI_API_KEY environment variable not set.")

API_BASE_URL = "https://us-east-1.recall.ai/api/v1"


def create_streaming_bot(meeting_url):
    """
    Calls the Recall.ai Create Bot API with the streaming configuration.

    Args:
        meeting_url: The URL of the meeting for the bot to join.

    Returns:
        The ID of the created bot, or None on failure.
    """
    endpoint = f"{API_BASE_URL}/bot/"
    headers = {
        "Authorization": f"Token {RECALL_API_KEY}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    # This is the new payload with the streaming provider configuration
    payload = {
        "meeting_url": meeting_url,
        "recording_config": {"transcript": {"provider": {"recallai_streaming": {}}}},
    }

    print(f"Attempting to create a streaming bot for meeting URL: {meeting_url}...")

    try:
        response = requests.post(endpoint, headers=headers, data=json.dumps(payload))
        response.raise_for_status()
        bot_data = response.json()
        bot_id = bot_data.get("id")

        if bot_id:
            print(f"Bot created successfully with ID: {bot_id}")
            return bot_id
        else:
            print("Failed to get a bot ID from the response.")
            return None
    except requests.exceptions.RequestException as e:
        print(f"An error occurred while creating the bot: {e}")
        return None


def get_bot_details(bot_id):
    """
    Retrieves the full details of a bot, including the transcript download URL.

    Args:
        bot_id: The ID of the bot to retrieve.

    Returns:
        A dictionary with the bot's details, or an empty dictionary on failure.
    """
    endpoint = f"{API_BASE_URL}/bot/{bot_id}/"
    headers = {"Authorization": f"Token {RECALL_API_KEY}", "Accept": "application/json"}

    print(f"\nAttempting to get details for bot ID: {bot_id}...")

    try:
        response = requests.get(endpoint, headers=headers)
        response.raise_for_status()
        bot_details = response.json()
        print("Bot details retrieved successfully.")
        return bot_details
    except requests.exceptions.RequestException as e:
        print(f"An error occurred while fetching bot details: {e}")
        return {}


def download_transcript(download_url):
    """
    Downloads the transcript from the provided URL.

    Args:
        download_url: The URL to download the transcript JSON from.

    Returns:
        A list of transcript segments, or an empty list on failure.
    """
    headers = {"Authorization": f"Token {RECALL_API_KEY}", "Accept": "application/json"}

    print(f"\nAttempting to download transcript from: {download_url}...")

    try:
        response = requests.get(download_url, headers=headers)
        response.raise_for_status()
        transcript = response.json()
        print("Transcript downloaded successfully.")
        return transcript
    except requests.exceptions.RequestException as e:
        print(f"An error occurred while downloading the transcript: {e}")
        return []


if __name__ == "__main__":
    # Replace with the actual URL of your meeting
    meeting_url = str(
        input("Enter the URL of your Google Meet instant meeting: ")
    ).strip()
    if not meeting_url:
        print("Meeting URL cannot be empty.")
        exit(1)

    # 1. Create the streaming bot
    bot_id = create_streaming_bot(meeting_url)

    if bot_id:
        print(
            "\nWaiting for the bot to join the meeting and for the recording to finish..."
        )
        print("Note: In a real application, you would use webhooks to get notified.")

        # Poll the API to check for the transcript download URL
        download_url = None
        for i in range(
            20
        ):  # Try up to 20 times (e.g., waiting 5 minutes in 15-second intervals)
            bot_details = get_bot_details(bot_id)
            try:
                # Navigate the JSON response to find the download URL
                download_url = bot_details["recordings"][0]["media_shortcuts"][
                    "transcript"
                ]["data"]["download_url"]
                if download_url:
                    break
            except (KeyError, IndexError):
                print(
                    f"Transcript URL not found yet. Retrying in 30 seconds... ({i+1}/20)"
                )
                time.sleep(30)

        if download_url:
            # 3. Download the final transcript
            transcript_data = download_transcript(download_url)

            if transcript_data:
                print("\n--- Final Transcript ---")
                for utterance in transcript_data:
                    speaker_name = utterance["participant"]["name"]
                    text = " ".join([word["text"] for word in utterance["words"]])
                    print(f"[{speaker_name}]: {text}")
            else:
                print(" Failed to download or parse the transcript.")
        else:
            print("\n Timed out waiting for the transcript to be ready.")
