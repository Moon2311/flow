 
# # config/settings/prod.py
# import os
# import ast
# from .base import *

# DEBUG = False

# # Parse allowed hosts from environment
# try:
#     ALLOWED_HOSTS = ast.literal_eval(os.getenv("ALLOWED_HOSTS", "[]"))
# except (SyntaxError, ValueError):
#     ALLOWED_HOSTS = []

# if not ALLOWED_HOSTS:
#     raise Exception("ALLOWED_HOSTS must be set in production!")
